import pandas as pd
import pandas_profiling as pf

my_report=pd.read_csv('Covid Data.csv')

profile= my_report.profile_report(title="corono profiling report")

report_copy=pf.ProfileReport(my_report)

report_copy.to_file('report/profile_report.html')